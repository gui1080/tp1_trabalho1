var class_preco =
[
    [ "getPreco", "class_preco.html#af70cb8f95d75b9a9abf71cea623c7e44", null ],
    [ "setPreco", "class_preco.html#af40f5c50a0d626fabda7ef51b712d9a1", null ]
];