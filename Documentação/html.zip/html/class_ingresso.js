var class_ingresso =
[
    [ "getIngresso", "class_ingresso.html#ac7ab2816caf4d6249a759dd3a00e87bd", null ],
    [ "setIngresso", "class_ingresso.html#ad2d5d6c3d6ad543d301ca5c9bc0299ff", null ]
];