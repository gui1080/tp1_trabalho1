var class_horario =
[
    [ "getHorario", "class_horario.html#a48bafd16811951544db6244ddc17e2ab", null ],
    [ "setHorario", "class_horario.html#a40c8660aecd2725dccd830b6248d1772", null ]
];