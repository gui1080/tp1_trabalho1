var class_codigo__de___evento =
[
    [ "getCodigo_de_Evento", "class_codigo__de___evento.html#a4340f17a848cca028ea926b891fcada2", null ],
    [ "setCodigo_de_Evento", "class_codigo__de___evento.html#a559ea991926bbc3d40aa15a88f942f77", null ]
];