var class_senha =
[
    [ "getSenha", "class_senha.html#a1cc904431d0a8287d0b22dee3e9d34ae", null ],
    [ "setSenha", "class_senha.html#a735e4bf5f65cc8d28daa7dbf202fd999", null ]
];