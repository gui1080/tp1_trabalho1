var class_faixa___etaria =
[
    [ "getFaixa_Etaria", "class_faixa___etaria.html#a4790b73d7795b5a99336c28907a2b764", null ],
    [ "setFaixa_Etaria", "class_faixa___etaria.html#ab51ddc1c74822761ab0295ce808b3ced", null ]
];