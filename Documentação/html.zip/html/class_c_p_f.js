var class_c_p_f =
[
    [ "getCPF", "class_c_p_f.html#abf57cf02d704d7e91e1c1399b9c88f95", null ],
    [ "setCPF", "class_c_p_f.html#a9469c05c56b436d6e96d1b6f6ad0d674", null ]
];