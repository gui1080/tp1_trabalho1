var class_numero__de___sala =
[
    [ "getNumero_de_Sala", "class_numero__de___sala.html#a3fa4226f51e3b1eac2f9e436272f7bbc", null ],
    [ "setNumero_de_Sala", "class_numero__de___sala.html#a8c856fec23369d40f2b3b1e1e11aef72", null ]
];