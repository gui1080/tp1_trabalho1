var class_apresentacao =
[
    [ "getApresentacao", "class_apresentacao.html#abc016724453abb89a25efc0f17483749", null ],
    [ "setApresentacao", "class_apresentacao.html#a6358207074e84c8fb42a1e62ff38e272", null ]
];