var class_nome__de___evento =
[
    [ "getNome_de_Evento", "class_nome__de___evento.html#af91a2b5b2335ded011091fe8e7f36f36", null ],
    [ "setNome_de_Evento", "class_nome__de___evento.html#a6c6291787aada3fa77d508929f73071f", null ]
];