var indexSectionsWithContent =
{
  0: "acdefghimnpsu",
  1: "acdefhinpsu",
  2: "dem",
  3: "gs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções"
};

