var class_evento =
[
    [ "getEvento", "class_evento.html#a4e76fe67592caac281dab09fa1353688", null ],
    [ "setEvento", "class_evento.html#a013016eb0c77c218ad7d3fc6e8e730db", null ]
];