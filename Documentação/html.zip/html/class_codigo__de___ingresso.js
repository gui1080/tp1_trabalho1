var class_codigo__de___ingresso =
[
    [ "getCodigo_de_Ingresso", "class_codigo__de___ingresso.html#af98bcedd8d0bf9d013d3b0195f1292dc", null ],
    [ "setCodigo_de_Ingresso", "class_codigo__de___ingresso.html#aa4c81505236d827400b0150158a65366", null ]
];