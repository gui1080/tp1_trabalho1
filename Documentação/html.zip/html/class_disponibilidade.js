var class_disponibilidade =
[
    [ "getDisponibilidade", "class_disponibilidade.html#a355cfd7df8d6cb7184353531e504ace9", null ],
    [ "setDisponibilidade", "class_disponibilidade.html#aa341bce5d792d82ccf8045f1b849f6a8", null ]
];