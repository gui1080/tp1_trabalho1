var class_cidade =
[
    [ "getCidade", "class_cidade.html#aa83cc66096e0672ca075e5e02db381f9", null ],
    [ "setCidade", "class_cidade.html#aeef5731f70dc20c2ede394dbd325d3f3", null ]
];