var class_usuario =
[
    [ "getUsuario", "class_usuario.html#a8a124cccf0b38c6df119522450da8968", null ],
    [ "setUsuario", "class_usuario.html#af922b47c545937c7a10f6672f01b9fa9", null ]
];