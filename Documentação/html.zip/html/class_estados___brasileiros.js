var class_estados___brasileiros =
[
    [ "getEstado", "class_estados___brasileiros.html#a346a8429f5c7b0fc1db9c88616854c3f", null ],
    [ "setEstado", "class_estados___brasileiros.html#a037a76c6e243e92b5bb2c9159d92ad01", null ]
];