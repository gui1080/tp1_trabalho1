var class_classe___evento =
[
    [ "getClasse_Evento", "class_classe___evento.html#af255a804405f406fa7d78a6ed8f75f77", null ],
    [ "setClasse_Evento", "class_classe___evento.html#a1bd655554107eb9539f01467a9a01c75", null ]
];